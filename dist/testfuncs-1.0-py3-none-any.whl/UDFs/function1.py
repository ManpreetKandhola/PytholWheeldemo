def stringLength(inStr):
    return len(inStr)