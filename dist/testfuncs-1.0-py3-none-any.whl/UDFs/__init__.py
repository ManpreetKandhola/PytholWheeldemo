from .function1 import stringLength
from .function2 import stringToUpper

some_string = "Hello, Universe!"

print(stringLength(some_string))
print(stringToUpper(some_string))