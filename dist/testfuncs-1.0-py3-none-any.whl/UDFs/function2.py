def stringToUpper(inStr):
    return inStr.upper()